package ej4;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import ejercicio4.Nodo;

public class GraphTraversalTool {
	
	private static int time = 0;
	
	public void depthFirstSearch(Graph g) {
		LinkedList<Node> verticesList = g.getVertices();
		for(Node n : verticesList) {
			n.setColor("white");			
		}
		time = 0;
		for (Node n : verticesList) {
			if (n.getColor().equalsIgnoreCase("white")) {
				visitNodeDFS(n);
			}
		}
	}
	
	public void visitNodeDFS(Node n) {
		n.setColor("yellow");
		incrementTime();
		n.setFoundTime(time);
		for(Node adyNode : n.getAdyacentNodes()) {
			if (adyNode.getColor().equals("white")) {
				visitNodeDFS(adyNode);				
			}
			//Ej 3 TP3 - Encontrar ciclo
			if (adyNode.getColor().equals("yellow")) {
				System.out.println("Hay ciclo");
			}
		}
		n.setColor("black");
		incrementTime();
		n.setFinishTime(time);		
	}
	
	public void BreadthFirstSearch(Graph g) {
		LinkedList<Node> verticesList = g.getVertices();
		//Reuso el campo color, blanco/white = no visitado, amarillo/yellow = visitado
		for (Node n : verticesList) {
			n.setColor("white");			
		}
		for (Node n : verticesList) {
			if (n.getColor().equals("white")) {
				BFS(n);				
			}
		}
	}
	
	public void BFS(Node n) {
		Queue<Node> queue = new ArrayDeque<Node>();
		n.setColor("yellow");
		queue.add(n);
		while(!queue.isEmpty()) {
			Node queueHead = queue.remove();
			for (Node adyNode : queueHead.getAdyacentNodes()) {
				if (adyNode.getColor().equals("white")) {
					adyNode.setColor("yellow");
					queue.add(adyNode);
				}
			}
		}
	}
	
	public void pathFinder(Graph g, Node start, Node goal) {
		LinkedList<Node> graphNodes = new LinkedList<Node>(g.getVertices());
		//Limpio el estado previo de los nodos
		for (Node n : graphNodes) {
			n.setColor("white");
		}		
		List<Node> path = new LinkedList<Node>();
		path = pF(start, goal, path);
		System.out.println("Total: ");
		System.out.println(path);
	}
	
	public List<Node> pF(Node act, Node goal, List<Node> path) {
		List<Node> adyNodes = act.getAdyacentNodes();
		if (!act.equals(goal)) {
			path.add(act);
			System.out.println("Act: " + act);
		}
		for (Node ady : adyNodes) {
			List<Node> nPath = pF(ady,goal,path);
			System.out.println("nPathy:");
			System.out.println(nPath);
			if (ady.equals(goal)) {
				System.out.println("goal");
				if (nPath.size() >= path.size()) {
					path = nPath;
				}				
				return path;
			}
		}
		return path;
				
	}
	
	public List<Node> altPathFinder(Graph g, Node nStart, Node nEnd) {
		//set all nodes color to white
		for (Node n : g.getVertices()) {
			n.setColor("white");
		}
		List<Node> path = new LinkedList<Node>();
		List<Node> longPath = new LinkedList<Node>();
		//altPF(nStart, nEnd, path);
		longPath = altPF2(nStart, nEnd, path, longPath);
		return longPath;
	}
		
	public List<Node> altPF2(Node actNode, Node nEnd, List<Node> path, List<Node> longPath) {
		if (actNode.hasAdyacentNodes()) {
			path.add(actNode);
			for (Node n : actNode.getAdyacentNodes()) {
				List<Node> branch = new LinkedList<Node>();
				branch.addAll(path);
				System.out.println("br: " + branch);
				System.out.println("lPath: " + longPath);
				System.out.println("b: " + branch.size() + " - l: " + longPath.size() + "\n");
				if (branch.size() > longPath.size()) {
					longPath = branch;
					//System.out.println(longPath);
				}
				altPF2(n, nEnd, branch, longPath);
			}
		}
		return longPath;
	}
		
	public void altBreadthFirstSearch(Graph g, Node nStart, Node nEnd) {
		//Reuso el campo color, blanco/white = no visitado, amarillo/yellow = visitado
		for (Node n : g.getVertices()) {
			n.setColor("white");			
		}
		int depth = 1;
		int maxDepth = 1;
		System.out.println(nStart);
		for (Node n : nStart.getAdyacentNodes()) {
			if (n.getColor().equals("white")) {
				altBFS(n, nEnd);
				System.out.println(n);
			}
		}
	}
	
	public void altBFS(Node n, Node nEnd) {
		Queue<Node> queue = new ArrayDeque<Node>();
		n.setColor("yellow");
		queue.add(n);
		while(!queue.isEmpty()) {
			Node queueHead = queue.remove();
			for (Node adyNode : queueHead.getAdyacentNodes()) {
				if (adyNode.getColor().equals("white")) {
					adyNode.setColor("yellow");
					queue.add(adyNode);
				}
				if (adyNode.equals(nEnd)) {
					System.out.println("goal found");
				}
			}
		}
	}
	
	public static void incrementTime() {
		time++;		
	}

	public static int getTime() {
		return time;
	}
	
	public static void resetTime() {
		time = 0;
	}

	
}
